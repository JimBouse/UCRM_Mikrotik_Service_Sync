This folder is an archive as of November 19, 2026 (America/Chicago).

The working copy now lives in:
  C:\Code Repo\LagoMar\_older-copies\Documents-GitHub-UCRM_Mikrotik_Service_Sync

Please edit files there, not here.

Nothing in this folder was deleted. This was a copy-only consolidation into C:\Code Repo.

The newest working files already lived at C:\Code Repo\LagoMar, so this git copy was stored under _older-copies. The git remote remains on this archive copy. Please edit C:\Code Repo\LagoMar going forward, and reconcile git before publishing.
